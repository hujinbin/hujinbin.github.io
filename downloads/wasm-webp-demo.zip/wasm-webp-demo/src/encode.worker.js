import encode from '@jsquash/webp/encode.js';

self.onmessage = async ({ data }) => {
  const { id, width, height, buffer, byteOffset, byteLength, quality } = data;
  try {
    const imageData = new ImageData(new Uint8ClampedArray(buffer, byteOffset, byteLength), width, height);
    // 首次调用会包含库内部初始化；后续调用复用同一个编码器实例。
    const started = performance.now();
    const encoded = await encode(imageData, { quality });
    const encodeMs = performance.now() - started;
    self.postMessage({ id, buffer: encoded, encodeMs }, [encoded]);
  } catch (error) {
    self.postMessage({ id, error: error instanceof Error ? error.message : String(error) });
  }
};
