import './styles.css';
import { createEncoder } from './encoder.js';

const $ = (id) => document.getElementById(id);
const canvas = $('source-canvas');
const context = canvas.getContext('2d', { willReadFrequently: true });
const fileInput = $('image-input');
const sampleButton = $('sample-button');
const encodeButton = $('encode-button');
const qualityInput = $('quality-input');
const resultImage = $('result-image');
const downloadButton = $('download-button');
const pendingURLs = new Set();
let encoder;
let source = null;
let outputURL = null;
let generation = 0;
let busy = false;
let loading = false;
let successfulCalls = 0;

function setActivity(text, error = false) {
  $('activity').textContent = text;
  $('activity').dataset.error = String(error);
}

function setEngineState(state, text) {
  $('engine-state').dataset.state = state;
  $('engine-state-text').textContent = text;
}

function updateControls() {
  encodeButton.disabled = busy || loading || !source || !encoder;
  sampleButton.disabled = busy;
  fileInput.disabled = busy;
  qualityInput.disabled = busy;
  downloadButton.setAttribute('aria-disabled', String(!outputURL || busy || loading));
  document.querySelector('.upload-button').classList.toggle('is-disabled', busy);
  document.querySelector('.previews').setAttribute('aria-busy', String(busy || loading));
  encodeButton.firstElementChild.textContent = busy ? '正在编码…' : '转换为 WebP';
}

function formatBytes(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KiB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MiB`;
}

function clearResult() {
  resultImage.removeAttribute('src');
  resultImage.hidden = true;
  if (outputURL) URL.revokeObjectURL(outputURL);
  outputURL = null;
  downloadButton.removeAttribute('href');
  downloadButton.setAttribute('aria-disabled', 'true');
  $('result-placeholder').hidden = false;
  $('result-format').textContent = '等待转换';
  $('result-dimensions').textContent = '输出预览 · 尚未生成';
  $('output-bytes').textContent = '—';
  $('output-exact').textContent = '转换后显示';
  $('savings-value').textContent = '—';
  $('savings-note').textContent = '与原始文件字节数比较';
  document.querySelector('.savings-metric').dataset.grown = 'false';
  $('elapsed-value').textContent = '—';
  $('encode-time').textContent = successfulCalls ? '后续调用复用已初始化的模块' : '首次包含 Wasm 模块初始化';
}

function paintSource(image, width, height) {
  const scale = Math.min(1, 2048 / Math.max(width, height));
  canvas.width = Math.max(1, Math.round(width * scale));
  canvas.height = Math.max(1, Math.round(height * scale));
  context.clearRect(0, 0, canvas.width, canvas.height);
  context.drawImage(image, 0, 0, canvas.width, canvas.height);
  return scale < 1;
}

function acceptSource(next) {
  source = next;
  clearResult();
  $('source-name').textContent = next.name;
  $('source-name').title = next.name;
  $('source-dimensions').textContent = `${canvas.width.toLocaleString()} × ${canvas.height.toLocaleString()} px`;
  $('resize-note').textContent = next.resized ? `已缩放 · 原始 ${next.width.toLocaleString()} × ${next.height.toLocaleString()} px` : '保持原始尺寸';
  $('original-bytes').textContent = formatBytes(next.bytes);
  $('original-exact').textContent = `${next.bytes.toLocaleString()} 字节${next.sample ? ' · 示例 PNG' : ` · ${next.format}`}`;
}

function makeSample() {
  const image = document.createElement('canvas');
  image.width = 1440; image.height = 960;
  const c = image.getContext('2d');
  const sky = c.createLinearGradient(0, 0, 1200, 960);
  sky.addColorStop(0, '#efd9ba'); sky.addColorStop(0.65, '#eeb57a'); sky.addColorStop(1, '#d96946');
  c.fillStyle = sky; c.fillRect(0, 0, image.width, image.height);
  const sun = c.createRadialGradient(470, 230, 5, 510, 310, 275);
  sun.addColorStop(0, '#ffe7a9'); sun.addColorStop(0.6, '#eab657'); sun.addColorStop(1, '#d97242');
  c.fillStyle = sun; c.beginPath(); c.arc(510, 310, 260, 0, Math.PI * 2); c.fill();
  c.fillStyle = '#759782'; c.fillRect(1010, 0, 430, 960);
  c.fillStyle = '#344d50'; c.beginPath(); c.moveTo(1010, 475); c.lineTo(1440, 210); c.lineTo(1440, 960); c.lineTo(1010, 960); c.closePath(); c.fill();
  c.fillStyle = '#f1b077'; c.fillRect(1110, 250, 140, 263);
  c.beginPath(); c.arc(1180, 250, 70, Math.PI, 0); c.fill();
  c.fillStyle = '#c65336'; c.fillRect(1155, 337, 50, 176);
  for (const [level, fill, height] of [[610, '#538e91', 130], [710, '#2a626f', 110], [815, '#204554', 85]]) {
    c.fillStyle = fill; c.beginPath(); c.moveTo(0, level);
    c.bezierCurveTo(280, level - height * 1.6, 540, level + height, 970, level - 30);
    c.bezierCurveTo(1160, level - 150, 1290, level - 70, 1440, level - 210);
    c.lineTo(1440, 960); c.lineTo(0, 960); c.closePath(); c.fill();
  }
  // 确定性的细小色点让示例同时包含渐变、纹理与清晰边缘。
  let seed = 1701;
  for (let i = 0; i < 14500; i++) {
    seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
    const x = seed % 1440;
    seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
    const y = seed % 960;
    c.fillStyle = i % 2 ? '#fff7df18' : '#163e4612'; c.fillRect(x, y, 2, 2);
  }
  c.strokeStyle = '#fff1d9a0'; c.lineWidth = 2; c.strokeRect(49, 49, 1342, 862);
  c.fillStyle = '#2c4443'; c.font = '23px Georgia, serif'; c.fillText('A SMALL PLACE / 02', 85, 110);
  c.fillStyle = '#dce5d7'; c.font = '18px monospace'; c.fillText('1440 × 960 / GENERATED LOCALLY', 85, 871);
  return image;
}

async function restoreSample() {
  if (busy) return;
  const version = ++generation;
  loading = true; updateControls();
  setActivity('正在生成本地示例和原始 PNG 文件…');
  try {
    const sample = makeSample();
    const blob = await new Promise(resolve => sample.toBlob(resolve, 'image/png'));
    if (version !== generation) return;
    if (!blob) throw new Error('浏览器未能生成示例 PNG。');
    paintSource(sample, sample.width, sample.height);
    acceptSource({ name: '内置示例 · PNG', filename: 'browser-lab.png', bytes: blob.size, width: sample.width, height: sample.height, resized: false, sample: true, format: 'PNG' });
    setActivity('本地示例已准备好，可以直接转换为 WebP。');
  } catch (error) {
    if (version === generation) setActivity(`示例准备失败：${error.message}`, true);
  } finally {
    if (version === generation) { loading = false; updateControls(); }
  }
}

function inspectStaticImage(buffer) {
  const bytes = new Uint8Array(buffer);
  const view = new DataView(buffer);
  const tag = (offset, length) => String.fromCharCode(...bytes.subarray(offset, offset + length));
  if (bytes.length >= 3 && bytes[0] === 255 && bytes[1] === 216 && bytes[2] === 255) return 'JPEG';
  if (bytes.length >= 8 && [137, 80, 78, 71, 13, 10, 26, 10].every((value, index) => bytes[index] === value)) {
    for (let offset = 8; offset + 12 <= bytes.length;) {
      const length = view.getUint32(offset);
      const type = tag(offset + 4, 4);
      if (type === 'acTL') throw new Error('当前示例仅处理静态图片，不接受 APNG 动画。');
      if (length > bytes.length - offset - 12) throw new Error('PNG 数据不完整。');
      offset += length + 12;
      if (type === 'IEND') break;
    }
    return 'PNG';
  }
  if (bytes.length >= 12 && tag(0, 4) === 'RIFF' && tag(8, 4) === 'WEBP') {
    for (let offset = 12; offset + 8 <= bytes.length;) {
      const type = tag(offset, 4);
      const length = view.getUint32(offset + 4, true);
      if (type === 'ANIM' || type === 'ANMF' || (type === 'VP8X' && length > 0 && (bytes[offset + 8] & 2))) throw new Error('当前示例仅处理静态图片，不接受 WebP 动画。');
      if (length > bytes.length - offset - 8) throw new Error('WebP 数据不完整。');
      offset += 8 + length + (length & 1);
    }
    return 'WebP';
  }
  throw new Error('请选择静态 JPG、PNG 或 WebP 文件，暂不支持 GIF、SVG 等格式。');
}

fileInput.addEventListener('change', async () => {
  const file = fileInput.files?.[0];
  if (!file || busy) return;
  const version = ++generation;
  loading = true; updateControls();
  setActivity('正在读取本机图片，没有上传文件…');
  let url;
  try {
    if (file.size > 32 * 1024 * 1024) throw new Error('请选择不超过 32 MiB 的图片。');
    const buffer = await file.arrayBuffer();
    if (version !== generation) return;
    const format = inspectStaticImage(buffer);
    url = URL.createObjectURL(new Blob([buffer], { type: format === 'JPEG' ? 'image/jpeg' : `image/${format.toLowerCase()}` }));
    pendingURLs.add(url);
    const image = new Image(); image.src = url;
    await image.decode();
    if (version !== generation) return;
    if (!image.naturalWidth || !image.naturalHeight) throw new Error('图片没有可用的宽高。');
    const resized = paintSource(image, image.naturalWidth, image.naturalHeight);
    acceptSource({ name: file.name, filename: file.name, bytes: file.size, width: image.naturalWidth, height: image.naturalHeight, resized, sample: false, format });
    setActivity(resized ? '图片已在本机缩放至长边 2,048 px，准备编码。' : '图片已在本机解码，准备编码。');
  } catch (error) {
    if (version === generation) setActivity(`图片读取失败：${error.message}`, true);
  } finally {
    if (url) { URL.revokeObjectURL(url); pendingURLs.delete(url); }
    if (version === generation) { loading = false; fileInput.value = ''; updateControls(); }
  }
});

async function encodeImage() {
  if (busy || loading || !source || !encoder) return;
  const version = generation;
  const original = source;
  const quality = Number(qualityInput.value);
  const firstCall = successfulCalls === 0;
  busy = true; updateControls();
  setEngineState('loading', firstCall ? '首次编码 · 正在加载 Wasm 并初始化编码器' : 'Worker 正在编码 · 页面保持响应');
  setActivity('正在把像素交给 Worker，完成后将直接生成本地文件…');
  let candidateURL;
  try {
    await new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)));
    const width = canvas.width, height = canvas.height;
    // encode 会转移这次读取的缓冲区；Canvas 中的原图始终保留。
    const pixels = context.getImageData(0, 0, width, height);
    const started = performance.now();
    const result = await encoder.encode(pixels, quality);
    const elapsed = performance.now() - started;
    if (version !== generation) return;
    if (!(result?.buffer instanceof ArrayBuffer) || !result.buffer.byteLength || !Number.isFinite(result.encodeMs) || result.encodeMs < 0) throw new Error('编码器返回了无效的 WebP 结果。');
    const blob = new Blob([result.buffer], { type: 'image/webp' });
    candidateURL = URL.createObjectURL(blob);
    pendingURLs.add(candidateURL);
    const preview = new Image(); preview.src = candidateURL;
    await preview.decode();
    if (version !== generation) return;
    if (preview.naturalWidth !== width || preview.naturalHeight !== height) throw new Error('编码结果的图片尺寸与输入不一致。');
    clearResult();
    outputURL = candidateURL;
    pendingURLs.delete(candidateURL); candidateURL = null;
    resultImage.src = outputURL; resultImage.hidden = false;
    $('result-placeholder').hidden = true;
    $('result-format').textContent = `WEBP · Q${quality}`;
    $('result-dimensions').textContent = `${width.toLocaleString()} × ${height.toLocaleString()} px`;
    $('output-bytes').textContent = formatBytes(blob.size);
    $('output-exact').textContent = `${blob.size.toLocaleString()} 字节 · 质量 ${quality}`;
    const savings = (1 - blob.size / original.bytes) * 100;
    $('savings-value').textContent = savings.toFixed(1);
    $('savings-note').textContent = savings < 0 ? '结果比原文件更大' : original.resized ? '包含缩放与编码的体积变化' : '与原始文件字节数比较';
    document.querySelector('.savings-metric').dataset.grown = String(savings < 0);
    $('elapsed-value').textContent = elapsed.toFixed(1);
    $('encode-time').textContent = `Worker 内 ${result.encodeMs.toFixed(1)} ms${firstCall ? ' · 本次为首次调用' : ' · 已复用模块'}`;
    downloadButton.href = outputURL;
    downloadButton.download = `${original.filename.replace(/\.[^.]+$/, '') || 'image'}-q${quality}.webp`;
    successfulCalls++;
    setEngineState('ready', 'Wasm 编码完成 · 后续转换复用已初始化的模块');
    setActivity('WebP 已在本机生成，可以预览或下载。');
  } catch (error) {
    if (version === generation) {
      setActivity(`转换失败：${error.message}。可重试，或选择另一张图片。`, true);
      setEngineState('error', '编码未完成 · 不会生成虚假的输出文件');
      // 出错后重建 Worker，避免失效实例让后续重试永久挂起。
      encoder.dispose();
      try { encoder = createEncoder(); successfulCalls = 0; } catch { encoder = null; }
    }
  } finally {
    if (candidateURL) { URL.revokeObjectURL(candidateURL); pendingURLs.delete(candidateURL); }
    busy = false; updateControls();
  }
}

qualityInput.addEventListener('input', () => {
  $('quality-value').textContent = qualityInput.value;
  if (outputURL) setActivity(`输出质量设为 ${qualityInput.value}；再次转换后更新结果，当前预览仍对应右上角标注的质量。`);
});
downloadButton.addEventListener('click', event => { if (!outputURL || busy || loading) event.preventDefault(); });
sampleButton.addEventListener('click', restoreSample);
encodeButton.addEventListener('click', encodeImage);
window.addEventListener('pagehide', () => {
  generation++;
  encoder?.dispose();
  for (const url of pendingURLs) URL.revokeObjectURL(url);
  pendingURLs.clear();
  if (outputURL) URL.revokeObjectURL(outputURL);
});
window.addEventListener('pageshow', event => {
  if (!event.persisted) return;
  // 从往返缓存恢复后，旧 Worker 与下载 URL 已释放，需要重新建立状态。
  try { encoder = createEncoder(); } catch { encoder = null; }
  successfulCalls = 0; busy = false; loading = false;
  clearResult(); updateControls();
  setEngineState(encoder ? 'idle' : 'error', encoder ? 'Wasm 按需加载 · 计算运行在 Worker' : '此浏览器无法创建 Web Worker，转换功能不可用。');
  setActivity('页面已恢复，请重新转换以生成可下载的 WebP。');
});

try { encoder = createEncoder(); }
catch { encoder = null; setEngineState('error', '此浏览器无法创建 Web Worker，转换功能不可用。'); }
await restoreSample();
