export function createEncoder() {
  const worker = new Worker(new URL('./encode.worker.js', import.meta.url), { type: 'module', name: 'webp-encoder' });
  let nextId = 1;
  let disposed = false;
  let startupError = null;
  const pending = new Map();

  const failAll = error => {
    for (const request of pending.values()) request.reject(error);
    pending.clear();
  };

  worker.addEventListener('message', ({ data }) => {
    const request = pending.get(data.id);
    if (!request) return;
    pending.delete(data.id);
    if (typeof data.error === 'string') {
      request.reject(new Error(data.error));
    } else if (!(data.buffer instanceof ArrayBuffer) || !Number.isFinite(data.encodeMs) || data.encodeMs < 0) {
      request.reject(new Error('编码 Worker 返回了无效结果'));
    } else {
      request.resolve({ buffer: data.buffer, encodeMs: data.encodeMs });
    }
  });
  worker.addEventListener('error', event => {
    startupError = new Error(`编码 Worker 无法启动或运行：${event.message || '请检查模块和 Wasm 资源是否通过 HTTP 正常加载'}`);
    failAll(startupError);
    worker.terminate();
  });
  worker.addEventListener('messageerror', () => {
    startupError = new Error('编码 Worker 消息传输失败');
    failAll(startupError);
    worker.terminate();
  });

  return {
    encode(imageData, quality) {
      if (disposed) return Promise.reject(new Error('编码器已关闭，请创建新的编码器'));
      if (startupError) return Promise.reject(startupError);
      if (!(imageData instanceof ImageData) || !(imageData.data instanceof Uint8ClampedArray)) {
        return Promise.reject(new TypeError('输入必须是有效 ImageData'));
      }
      if (!Number.isFinite(quality) || quality < 0 || quality > 100) {
        return Promise.reject(new RangeError('WebP 质量必须在 0 到 100 之间'));
      }
      const { width, height, data } = imageData;
      if (!Number.isInteger(width) || !Number.isInteger(height) || width <= 0 || height <= 0 || data.byteLength !== width * height * 4) {
        return Promise.reject(new RangeError('图像尺寸与 RGBA 数据不匹配，或者输入缓冲区已经被转移'));
      }
      const id = nextId++;
      return new Promise((resolve, reject) => {
        pending.set(id, { resolve, reject });
        try {
          // 所有权转移后主线程的输入缓冲区失效，调用方不能再次使用该 ImageData。
          worker.postMessage({ id, width, height, quality, buffer: data.buffer, byteOffset: data.byteOffset, byteLength: data.byteLength }, [data.buffer]);
        } catch (error) {
          pending.delete(id);
          reject(error);
        }
      });
    },
    dispose() {
      if (disposed) return;
      disposed = true;
      worker.terminate();
      failAll(new Error('编码器已关闭，待处理任务已取消'));
    },
  };
}
