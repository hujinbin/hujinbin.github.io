# 第三方软件许可与来源

本案例的预构建 `dist/` 包含 jSquash WebP 编码器、预编译 libwebp WebAssembly 模块，以及用于选择 SIMD 实现的 wasm-feature-detect 代码。以下许可证文件从本案例实际安装的 npm 包中直接复制，保留原文与上游版权声明。

## @jsquash/webp 1.5.0

- 上游项目：[jSquash](https://github.com/jamsinclair/jSquash)。
- 固定版本发布包：[webp-1.5.0.tgz](https://registry.npmjs.org/@jsquash/webp/-/webp-1.5.0.tgz)。
- 原文件：`@jsquash/webp/LICENSE`。
- 许可证：[Apache License 2.0 原文](licenses/jsquash-webp-1.5.0-LICENSE.txt)。
- 运行时用途：WebP 编码选项、Wasm 初始化与普通／SIMD 编码器 JavaScript 包装。

该发布包许可证保留的版权行：

```text
Copyright [2023] jamsinclair
```

该包 `encode.js` 源码头部另含以下上游声明：

```text
Copyright 2020 Google Inc. All Rights Reserved.
Licensed under the Apache License, Version 2.0 (the "License");
```

## libwebp 编码器

- 上游项目：[webmproject/libwebp](https://github.com/webmproject/libwebp)。
- 本例取得许可文本的发布包：上述 `@jsquash/webp` 1.5.0。
- 原文件：`@jsquash/webp/codec/LICENSE.codec.md`。
- 许可证：[BSD 三条款原文](licenses/libwebp-LICENSE.codec.txt)。
- 运行时用途：`webp_enc*.wasm` 中的 WebP 编码实现。
- 该包附带的 `codec/README.md` 与 `codec/enc/README.md` 将上游源码版本标为 `v1.0.2`；这里忠实记录发布包说明，没有把该标注当作对二进制内部版本的独立检测结果。

版权声明原文：

```text
Copyright (c) 2010, Google Inc. All rights reserved.
```

完整的再分发条件、名称使用限制与免责声明保留在上述许可证文件中。

## wasm-feature-detect 1.9.0

- 上游项目：[GoogleChromeLabs/wasm-feature-detect](https://github.com/GoogleChromeLabs/wasm-feature-detect)。
- 固定版本发布包：[wasm-feature-detect-1.9.0.tgz](https://registry.npmjs.org/wasm-feature-detect/-/wasm-feature-detect-1.9.0.tgz)。
- 原文件：`wasm-feature-detect/LICENSE`。
- 许可证：[Apache License 2.0 原文](licenses/wasm-feature-detect-1.9.0-LICENSE.txt)。
- 运行时用途：检测 SIMD 支持，选择可用的 WebP 编码器。

版权声明原文：

```text
Copyright 2017 Google Inc.
```

## 构建工具与分发文件

Vite 8.3.5 是本案例的开发和构建依赖，上游项目为 [vitejs/vite](https://github.com/vitejs/vite)，其 npm 包声明采用 MIT 许可证。运行预构建 `dist/` 时不加载 Vite 包；本说明没有将整个开发依赖目录归入浏览器运行时内容。

项目根目录、`public/` 与当前 `dist/` 中均附有本说明及对应 `licenses/` 文件。`public/` 中的副本会由后续 Vite 构建继续带入 `dist/`。复制或发布预构建页面时，请把 `THIRD_PARTY_NOTICES.md` 和 `licenses/` 一起保留，不要只分发 `.js` 与 `.wasm`。
