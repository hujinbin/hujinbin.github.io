import { defineConfig } from 'vite';

export default defineConfig({
  base: './',
  optimizeDeps: { exclude: ['@jsquash/webp'] },
  worker: { format: 'es' },
});
