import { createServer } from 'node:http';
import { createReadStream } from 'node:fs';
import { realpath, stat } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.join(path.dirname(fileURLToPath(import.meta.url)), 'dist');
const args = process.argv.slice(2);
const portArgument = args.indexOf('--port');
const port = Number(portArgument >= 0 ? args[portArgument + 1] : process.env.PORT || 4180);
if (!Number.isInteger(port) || port < 1 || port > 65535 || !(args.length === 0 || (args.length === 2 && args[0] === '--port'))) {
  console.error('用法：node serve.mjs [--port 4180]，或设置 PORT 环境变量');
  process.exit(1);
}
let canonicalRoot;
try {
  canonicalRoot = await realpath(root);
  await stat(path.join(root, 'index.html'));
} catch {
  console.error('缺少 dist/index.html。预构建案例需要携带 dist；修改源码后请先 npm install && npm run build。');
  process.exit(1);
}
const mime = new Map([
  ['.html', 'text/html; charset=utf-8'], ['.js', 'text/javascript; charset=utf-8'],
  ['.css', 'text/css; charset=utf-8'], ['.wasm', 'application/wasm'],
  ['.json', 'application/json; charset=utf-8'], ['.svg', 'image/svg+xml'],
  ['.webp', 'image/webp'], ['.png', 'image/png'], ['.jpg', 'image/jpeg'],
  ['.jpeg', 'image/jpeg'], ['.ico', 'image/x-icon'],
]);
const server = createServer(async (request, response) => {
  if (!['GET', 'HEAD'].includes(request.method)) {
    response.writeHead(405, { Allow: 'GET, HEAD' }).end('Method not allowed');
    return;
  }
  try {
    const pathname = decodeURIComponent(new URL(request.url, 'http://127.0.0.1').pathname);
    const target = path.resolve(canonicalRoot, `.${pathname === '/' ? '/index.html' : pathname}`);
    const actual = await realpath(target);
    const relative = path.relative(canonicalRoot, actual);
    if (relative === '..' || relative.startsWith(`..${path.sep}`) || path.isAbsolute(relative)) {
      response.writeHead(403).end('Forbidden');
      return;
    }
    const info = await stat(actual);
    if (!info.isFile()) {
      response.writeHead(404).end('Not found');
      return;
    }
    response.writeHead(200, {
      'Content-Type': mime.get(path.extname(actual).toLowerCase()) || 'application/octet-stream',
      'Content-Length': info.size,
      'Cache-Control': 'no-cache',
      'X-Content-Type-Options': 'nosniff',
    });
    if (request.method === 'HEAD') { response.end(); return; }
    const stream = createReadStream(actual);
    stream.on('error', () => response.destroy());
    stream.pipe(response);
  } catch (error) {
    const malformed = error instanceof URIError;
    response.writeHead(malformed ? 400 : 404).end(malformed ? 'Bad request' : 'Not found');
  }
});
server.on('error', error => {
  console.error(`服务器启动失败：${error.message}`);
  process.exitCode = 1;
});
server.listen(port, '127.0.0.1', () => console.log(`WebP Wasm 案例：http://127.0.0.1:${port}`));
for (const signal of ['SIGINT', 'SIGTERM']) process.on(signal, () => server.close());
