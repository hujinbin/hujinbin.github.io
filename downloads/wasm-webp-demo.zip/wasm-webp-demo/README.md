# 浏览器 WebAssembly WebP 编码案例

这是一个纯前端案例：浏览器读取图片并取得 RGBA 像素，将数据转移到 Web Worker，由 `@jsquash/webp` 提供的预编译 WebAssembly 编码器生成 WebP，再把结果返回给页面预览和下载。图片数据在当前浏览器内处理，没有图片上传接口。

本案例不用编写或编译 C++，不需要 Emscripten、Docker 或 Python 后端。

## 直接运行预构建案例

如果目录已经包含 `dist/`，只需要 Node.js：

```bash
npm start
```

等价命令：

```bash
node serve.mjs
```

打开终端提示的 [本地页面](http://127.0.0.1:4180)。这两条命令只运行 Node 内置 HTTP 服务器，不加载 Vite，也不需要先安装 npm 依赖。

修改端口：

```bash
node serve.mjs --port 4181
```

请通过 HTTP 访问，不要直接双击 `index.html`。页面需要通过 HTTP 加载 ES Module、Worker 和 `.wasm` 文件。服务器只公开 `dist/`，绑定到 `127.0.0.1`。

## 修改源码与重新构建

开发需要 Node.js 22.12 或更新版本：

```bash
npm ci
npm run dev
```

生成可分发的预构建页面：

```bash
npm run build
npm start
```

项目固定使用 `@jsquash/webp` 1.5.0 与 Vite 8.3.5，并包含 `package-lock.json`。Vite 使用 `base: './'`，将 Worker 及普通／SIMD 编码器的 JavaScript、Wasm 资源打包到 `dist/`。`worker.format: 'es'` 用于支持库内部的动态导入；依赖优化排除 `@jsquash/webp`，保持其 Wasm 资源定位逻辑。

分发时保留整个 `dist/`，不要只复制 `index.html`，也不要改名或删除 `dist/assets/` 里的文件。`node_modules/` 不属于运行预构建页面所需的文件。

## 编码调用接口

```javascript
import { createEncoder } from './src/encoder.js';

const encoder = createEncoder();
const imageData = context.getImageData(0, 0, canvas.width, canvas.height);
const { buffer, encodeMs } = await encoder.encode(imageData, 80);
const blob = new Blob([buffer], { type: 'image/webp' });

// 页面卸载或不再需要编码器时调用。
encoder.dispose();
```

上例源码需要通过 Vite 开发服务器或构建流程处理。`@jsquash/webp/encode.js` 的真实调用方式是 `encode(imageData, { quality })`，结果为 `ArrayBuffer`；本例将它封装在 Module Worker 中。

`encode` 会转移传入的 `imageData.data.buffer` 所有权，传输成功后主线程中的原缓冲区失效。不要重复使用同一个 `ImageData`；每次重新编码时从源 Canvas 再次取得像素。质量值必须是 0 到 100 的有限数字。

请求通过递增 `id` 匹配各自的 Promise。Worker 运行异常、加载异常和消息传输失败会向调用方传播；`dispose()` 会终止 Worker 并拒绝所有尚未完成的请求，调用关闭后的编码器也会返回失败。

## 耗时含义

`encodeMs` 在 Worker 内计时，范围是调用 `encode(imageData, { quality })` 到其 Promise 完成。库在首次调用时初始化 Wasm，因此首轮包含这部分初始化成本，后续调用复用初始化结果。

该数值不包含图片文件读取、浏览器解码、Canvas 像素读取、主线程与 Worker 消息等待、结果图片解码与页面绘制。页面应只在用户点击编码按钮时运行编码任务，不在拖动质量滑块时重复编码。

实际输出大小与画面内容、尺寸和质量相关，WebP 结果不保证小于原文件。此案例不宣称固定的压缩率或 JavaScript 对比加速倍数。

## 文件分工

| 文件 | 用途 |
| --- | --- |
| `src/encoder.js` | Worker 生命周期、参数检查与 Promise 请求匹配 |
| `src/encode.worker.js` | 调用预编译 Wasm WebP 编码器 |
| `vite.config.js` | 相对资源路径、Worker 模块格式与依赖排除 |
| `serve.mjs` | 使用 Node 内置模块提供 `dist/` 静态服务 |
| `dist/` | 构建后的完整浏览器运行文件 |

编码器来自 [jSquash](https://github.com/jamsinclair/jSquash)，`@jsquash/webp` npm 包声明采用 Apache-2.0 许可证。重新分发第三方资源时请保留对应许可声明。
